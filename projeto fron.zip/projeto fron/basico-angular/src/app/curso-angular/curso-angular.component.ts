import { Component } from '@angular/core';

@Component({
  selector: 'app-curso-angular',
  templateUrl: './curso-angular.component.html',
  styleUrls: ['./curso-angular.component.css']
})
export class CursoAngularComponent {

}
